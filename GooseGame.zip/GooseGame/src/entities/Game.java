package entities;

import java.util.ArrayList;

public class Game 
{
	Gameboard board = new Gameboard();
	ArrayList<Player> players = new ArrayList<Player>();
	Dice dice = new Dice();
	
	//costruttore vuoto
	Game(){}
	
	//aggiunta giocatore
	public boolean addPlayer(Player p)
	{
		for(Player pl : players)
		{
			if(pl.getName().equalsIgnoreCase(p.getName()))
			{
				return false;
			}
		}
		players.add(p);
		return true;
	}
	
	//elenco players
	public String listPlayers()
	{
		String res="Players: \n";
		for(Player pl : players)
			res+=pl.getName() + "\n";
		return res;
	}
	
	//minimo giocatori a partita
	public boolean minPlayers()
	{
	return players.size()>=2;
	}
	
	public String move(int i)
	{
		String res="";
		res+= players.get(i).move(dice.launch(), dice.launch());
		res +=players.get(i).effect(board.effectCell(players.get(i)));
		return res;  
	}
	
	public String playersPosition()
	{
		String res="";
		for(Player p : players)
		{
			res+="Il player "+p.getName()+" è in posizione: " + p.getPosition()+"\n";
		}
		return res;
	}
	
	
	
}
