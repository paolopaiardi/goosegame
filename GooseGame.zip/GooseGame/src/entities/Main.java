package entities;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		Game g = new Game();
		Scanner s = new Scanner (System.in);
		String menu = "Benvenuto al gioco dell'Oca\n \n" + 
									"Premi 1 per aggiungere Player \n" + 
									"Premi 2 per Avviare Game\n" + 
									"Premi 3 per Terminare il Gioco ";
		while (true)
		{
			System.out.println(menu);
			
			
			String comando = s.nextLine();
			switch(comando)
			{
				case "1":
					System.out.println("Inserisci Nome Player");
					if(g.addPlayer(new Player(s.nextLine())))
					{
						System.out.println(g.listPlayers());
					}
					else System.out.println("Player già esistente");	
				break;	
			
				case "2":
					if(!g.minPlayers())
					{
						System.out.println("minimo 2 players, aggiungere player");
						break;
					}
					while(true)
					{
						for(int i=0; i<g.players.size(); i++)
						{
							String cmd = "";
							do 
							{
								System.out.println(g.players.get(i).getName() + "\nPremi 1 per lanciare e muovere\n"
										+ "Premi 2 per conoscere posizione dei Players");
								cmd = s.nextLine();
								switch (cmd)
								{	case "1":
									System.out.println(g.move(i));
									g.players.get(i).winCheck(g.players.get(i));
									break;
									
									case "2":
									System.out.println(g.playersPosition());
								}
							}
							while (!cmd.equalsIgnoreCase("1"));
							
						}
					
					}
					
			case "3":
				System.out.println("Gioco Terminato");
//				System.exit(1);
				break;
				
			}
//			s.close();
		}
	}
	
}
