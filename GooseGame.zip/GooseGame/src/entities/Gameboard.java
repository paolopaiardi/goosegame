package entities;

import java.util.HashMap;
import java.util.Map;

public class Gameboard 
{
	Map<Integer,String> gameboard = new HashMap <Integer,String>();

	//mappa del tabellone
	public Gameboard() 
	{
		this.gameboard.put(6, "bridge");
		this.gameboard.put(5, "jump");
		this.gameboard.put(9, "jump");
		this.gameboard.put(14, "jump");
		this.gameboard.put(18, "jump");
		this.gameboard.put(23, "jump");
		this.gameboard.put(27, "jump");
		
	}
	
	//gestione dell'effetto della cella
	public String effectCell(Player p)
	{
		for(int i : gameboard.keySet())
		{
			if (i==p.getPosition())
			{
				return gameboard.get(i);
			}
		}
		return "";
	}
	
	
	
	
	
	
}
