package entities;
import java.util.Random;

public class Dice {

	  private Random generator;
	  private int face;

	  public Dice(int s)
	  {
		  face = s;
		   generator = new Random();
	  }

	  public Dice()
	  {
		  face = 6;
		  generator = new Random();
	  }

	  public int launch()
	  {
	      return 1 + generator.nextInt(face);
	  }
}
