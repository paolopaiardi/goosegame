package entities;

public class Player 
{
	
	private String name;
	private int position=0;
	private final int wincell=63;
	private int diceSum = 0;
	
	Player(String name)
	{
		this.name=name;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() 
	{
		return name;
	}
	
	// metodo per il movimento del player
	public String move(int dice1, int dice2)
	{
		setDiceSum(dice1+dice2);
		position += diceSum;
		overWinCell();
		return "Il giocatore si muove in posizione: \n" + position;
	}

	
	public int getPosition() {
		return position;
	}

	public void setPosition(int position) 
	{
		this.position = position;
	}
	
	// metodo di controllo >63
	public void overWinCell() 
	{
		if (position>wincell)
		{
			position= wincell-(position-wincell); 
		}
	}

	public int getDiceSum() {
		return diceSum;
	}

	public void setDiceSum(int diceSum) {
		this.diceSum = diceSum;
	}

	public int getWincell() 
	{
		return wincell;
	}
	
	public String effect(String e)
	{
		String res="";
		switch(e)
		{
			case "jump":
				move(diceSum ,0);
				res = "\nJUMPPPPP!";
				break;	
			
			case "bridge":
				move(3,3);
				res= "\nBRIDGEEEEEE!";
				break;
		}
		return res;
		
	}

	
	public void winCheck(Player p)
	{
		String res="";
		if(p.position==wincell)
		{
			res="CONGRATULATIONS!!! Hai vinto, programma terminato";
			System.out.println(p + "\n " + res);
			System.exit(1);
		}

	}
}
